# Stores a name in a variable

name = input("What's your name? ")
print(f"hello, {name}")
